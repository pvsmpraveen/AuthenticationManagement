create trigger S
  before insert or update
  on STUDD
  for each row
declare
s studd.stuname%type;
begin
select stuname into s from studd where sid=10;
if(:new.stuname=s) then
raise_application_error(-56999,'this is error');
end if;
end;
/

