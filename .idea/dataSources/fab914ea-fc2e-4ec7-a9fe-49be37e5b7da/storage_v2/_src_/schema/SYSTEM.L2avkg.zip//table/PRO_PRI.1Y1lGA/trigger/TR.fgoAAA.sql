create trigger TR
  before update
  on PRO_PRI
  for each row
begin
insert into his_pri values(:old.pro_name,:old.price);
end;
/

