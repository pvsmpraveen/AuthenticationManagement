create trigger TRIG_O
  before update or delete
  on EMP_O
  for each row
begin
insert into emp_n values(:old.empno,:old.ename,:old.deptid);
end;
/

