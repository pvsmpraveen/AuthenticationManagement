create trigger T
  before insert or update or delete
  on COLLAGE
  for each row
begin
raise_application_error('-3444','you cannot modify');
end;
/

