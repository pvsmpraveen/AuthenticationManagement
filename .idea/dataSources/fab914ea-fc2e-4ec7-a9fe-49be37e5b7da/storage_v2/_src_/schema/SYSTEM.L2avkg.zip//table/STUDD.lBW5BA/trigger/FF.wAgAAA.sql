create trigger FF
  before insert or update
  on STUDD
  for each row
declare
ff stuname.studd%type;
begin
select stuname into ff from studd where sid=10;
if(:new.stuname=ff) then
raise_application_error(-56999,'this is error');
end if;
end;
/

