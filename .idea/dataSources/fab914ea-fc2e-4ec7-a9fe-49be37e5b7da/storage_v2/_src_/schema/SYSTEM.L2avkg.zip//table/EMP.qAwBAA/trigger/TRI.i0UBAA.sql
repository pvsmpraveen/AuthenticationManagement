create trigger TRI
  before insert or update or delete
  on EMP
  for each row
declare
sal_diff number(3);
begin
sal_diff:=:new.sal-:old.sal;
dbms_output.put_line('old salary:'||:old.sal);
dbms_output.put_line('new salary:'||:new.sal);
dbms_output.put_line('difference:'||sal_diff);
end;
/

